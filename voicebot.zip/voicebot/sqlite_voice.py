import sqlite3 as sq

def db_start():
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('CREATE TABLE IF NOT EXISTS users('
                           'user_id INTEGER NOT NULL,'
                           'simvols TEXT NOT NULL DEFAULT 10000,'
                           'book INTEGER NOT NULL DEFAULT 0,'
                           'counter INTEGER NOT NULL DEFAULT 0,'
                           'api_key TEXT NOT NULL DEFAULT "Нет",'
                           'UNIQUE(user_id))')



def db_book():
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('CREATE TABLE IF NOT EXISTS books('
                           'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                           'book TEXT,'
                           'urls TEXT,'
                           'UNIQUE(book))')


#Добавление книг
def insert_book(book, urls):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        cur.execute('INSERT INTO books(book, urls) VALUES(?,?)', (book, urls))
        db.commit()

#Забираем книгу
def book_send(book):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('SELECT urls FROM books WHERE book = ?', (book,)).fetchall()[0]

#Удаляем книгу
def book_delete(book):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        cur.execute('DELETE FROM books WHERE book = ?', (book,))
        db.commit()
#Проверка книги
def book_exists(book):
    with sq.connect('database.db') as db:
        cur = db.cursor()
        result = cur.execute('SELECT * FROM books WHERE book = ?', (book,)).fetchall()
        return bool(len(result))

#Обновить API
def add_api(user_id, api):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('UPDATE users SET api_key = ? WHERE user_id = ?', (api, user_id))


#Выдать полный доступ
def add_status(user_id, simvols):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('UPDATE users SET simvols = simvols + ? WHERE user_id = ?', ( simvols, user_id))

def all_user():
    with sq.connect('database.db') as db:
        cur = db.cursor()
        return cur.execute('SELECT user_id FROM users').fetchall()

#Выдать полный доступ
def add_book(user_id, book):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('UPDATE users SET book = book + ? WHERE user_id = ?', (book, user_id))

def stat():
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('SELECT count(user_id), sum(book) FROM users').fetchall()[0]




#Выдать полный доступ
def minus_simvols(user_id, simvols):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('UPDATE users SET simvols = simvols - ? WHERE user_id = ?', ( simvols, user_id))


#Удалить полный доступ
def delete_status(user_id, simvols):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('UPDATE users SET simvols = simvols - ? WHERE user_id = ?', (simvols, user_id))


#Забираем API
def send_api(user_id):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return cur.execute('SELECT api_key FROM users WHERE user_id = ?', (user_id,)).fetchall()[0]

# Проверка пользователя
def user_exists(user_id):
    with sq.connect('database.db') as db:
        cur = db.cursor()
        result = cur.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)).fetchall()
        return bool(len(result))


def add_users(user_id):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        cur.execute('INSERT INTO users(user_id) VALUES (?)', (user_id,))
        db.commit()


def chek_status(user_id):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return  cur.execute('SELECT simvols FROM users WHERE user_id = ?', (user_id,)).fetchall()[0]

def chek_book(user_id):
    with sq.connect('database.db') as db:
        cur = db.cursor()

        return  cur.execute('SELECT book FROM users WHERE user_id = ?', (user_id,)).fetchall()[0]


def main():
    db_start()
    db_book()

if __name__ == '__main__':
    main()