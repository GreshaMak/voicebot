token = '7040865400:AAFlagQgNU5JDY7idnLMsyJUgzvbIUi7gtY' #Токен бота
ADMIN = 7016182279 #id Админа
#6030853197
CHANNALS = 'https://t.me/qumati_bots' #ссылкка на канал для подписки в разделах О НАС

DIR = '' #Укажите полный путь до папки с ботом

chanals = [
    ['Разработчик', '-1002231050658', 'https://t.me/qumati_bots'],  #Обязательная подписка 1-название канала, 2-id канала, 3-ссылка на канал
    #ВАЖНО! Бот должен быть администратором в этих каналах
            ]

#Вход в админку
#/admin

#///////////////Зависимости\\\\\\\\\\\\\\\\\\
#pip install aiogram==2.25.1
#pip install requests
#pip install db-sqlite3