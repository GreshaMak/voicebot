﻿import json
import os
import random
import string
import time

import requests
from aiogram import types, Bot, Dispatcher, executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import StatesGroup, State
from config import *
from sqlite_voice import *
from keybord import *


storage = MemoryStorage()
bot = Bot(token)
dp = Dispatcher(bot, storage=storage)


#Проверка подписки
async def chec_shanel(channels, user):
    for channal in channels:
        chat_member = await bot.get_chat_member(chat_id=channal[1], user_id=user)
        if chat_member['status'] == 'left':
            return False
    return True


@dp.callback_query_handler(text='stop_input', state='*')
async def stop_input(callback: types.CallbackQuery, state: FSMContext):
    if state is None:
        return
    else:
        await callback.message.edit_text('Вы в главном меню')
        await state.finish()

@dp.message_handler(commands=['start'], state='*')
async def smd_start(message: types.Message):
    db_start()
    db_book()
    if await chec_shanel(channels=chanals, user=message.from_user.id):
        await bot.send_message(message.from_user.id, 'Перевод книг из текстового формата в аудиокнигу', reply_markup=kb_menu)
        if not user_exists(message.from_user.id):
            add_users(message.from_user.id)

    else:
        await bot.send_sticker(message.from_user.id,
                               sticker='CAACAgIAAxkBAAJMyWTSOpPsWhJZKWzpAAHUiZfxdLrqIQACXAADUomRI1aEI4rcKZp0MAQ')
        await bot.send_message(chat_id=message.from_user.id,
                               text='Для того чтобы пользоваться нашим ботом, подпишитесь на каналы',
                               reply_markup=show_canals())



@dp.callback_query_handler(text='done')
async def chek_subs(message: types.Message):
    await bot.delete_message(message.from_user.id, message.message.message_id)
    if await chec_shanel(channels=chanals, user=message.from_user.id):
        await bot.send_message(message.from_user.id, 'Перевод книг из текстового формата в аудиокнигу', reply_markup=kb_menu)
        if not user_exists(message.from_user.id):
            add_users(message.from_user.id)

    else:
        await bot.send_sticker(message.from_user.id,
                               sticker='CAACAgIAAxkBAAJMyWTSOpPsWhJZKWzpAAHUiZfxdLrqIQACXAADUomRI1aEI4rcKZp0MAQ')
        await bot.send_message(chat_id=message.from_user.id,
                               text='Для того чтобы пользоваться нашим ботом, подпишитесь на каналы', reply_markup=show_canals())


@dp.message_handler(text='Сканирование 🤖', state='*')
async def cmd_voice(message: types.Message):
    if await chec_shanel(channels=chanals, user=message.from_user.id):
        with open('Dmitriy test.mp3', 'rb') as audio:
            await bot.send_audio(message.from_user.id, audio=audio, caption='Выберите подходящую озвучку,ниже будут тестовые озвучки', reply_markup=ikb_voice)
    else:
        await bot.send_sticker(message.from_user.id,
                               sticker='CAACAgIAAxkBAAJMyWTSOpPsWhJZKWzpAAHUiZfxdLrqIQACXAADUomRI1aEI4rcKZp0MAQ')
        await bot.send_message(chat_id=message.from_user.id,
                               text='Для того чтобы пользоваться нашим ботом, подпишитесь на каналы',
                               reply_markup=show_canals())

class User_voice(StatesGroup):
    doc = State()

@dp.callback_query_handler(text='dmitryi')
async def dm(callback: types.CallbackQuery):
    await callback.message.delete()
    if await chec_shanel(channels=chanals, user=callback.from_user.id):
        await callback.message.answer('Отправьте пожалуйста <b>текстовый (Расширение txt!)</b> файл\n\n'
                                         '⚠ Максимальный лимит за один запрос - 10.000 символов', parse_mode='HTML', reply_markup=ikb_stop)
        await User_voice.doc.set()
    else:
        await bot.send_sticker(callback.from_user.id,
                               sticker='CAACAgIAAxkBAAJMyWTSOpPsWhJZKWzpAAHUiZfxdLrqIQACXAADUomRI1aEI4rcKZp0MAQ')
        await bot.send_message(chat_id=callback.from_user.id,
                               text='Для того чтобы пользоваться нашим ботом, подпишитесь на каналы',
                               reply_markup=show_canals())




@dp.message_handler(content_types=['document'], state=User_voice.doc)
async def documents(message: types.Message, state:FSMContext):
    await message.answer('Генерирую аудиозапись....')


    api = send_api(ADMIN)
    name = message.document.file_name
    nums = ''.join(random.choice(string.digits) for i in range(1, 7))
    if not os.path.exists("output"):
        os.mkdir("output")
    res = nums + name
    destination = fr"{DIR}/output/{res}"
    destination_file = await message.document.download(destination)
    text = []
    with open(f'output/{res}', 'r', encoding='utf-8') as file:
        text.append(file.read())

    result = ''.join(text)

    balance_user = chek_status(message.from_user.id)

    if int(balance_user[0]) < int(len(result)):
        await state.finish()
        return await message.answer('У вас не хватает символов, чтобы пополнить символы - напишите @bovup')



    if int(len(result)) > 9999:
        await message.answer('Вы превысили количество символов, максимальное количество: 10.000 символов')
        await state.finish()

    url = 'https://developer.voicemaker.in/voice/api'
    headers = {
        'Authorization': f'Bearer {api[0]}',
        'Content-Type': 'application/json'
    }

    data = {
        'Engine': 'neural',
        'VoiceId': 'ai3-ru-RU-Dmitry',
        "LanguageCode": "ru-RU",
        "Text": f"{result}",
        "OutputFormat": "mp3",
        "SampleRate": "48000",
        "Effect": "default",
        "MasterSpeed": "0",
        "MasterVolume": "0",
        "MasterPitch": "0"
    }

    response = requests.post(url, data=json.dumps(data), headers=headers)
    results = json.loads(response.text)
    # if int(results['usedChars']) > 9999:
    #


    audio_url = results['path']
    audio = requests.get(audio_url)

    with open('Voice.mp3', 'wb') as file:
        file.write(audio.content)
    audio = open('Voice.mp3', 'rb')
    await bot.send_audio(message.from_user.id, audio)
    minus_simvols(message.from_user.id, results['usedChars'])
    add_book(message.from_user.id, 1)
    audio.close()
    os.remove('/home/BOT/Voice.mp3')
    await state.finish()








@dp.message_handler(text='Профиль 👀', state='*')
async def cmd_profile(message: types.Message):
    await bot.send_sticker(message.from_user.id, sticker='CAACAgIAAxkBAAJMy2TSOv9zRHIoGw5lMVfs_pTS98BoAAJGAANSiZEj-P7l5ArVCh0wBA')
    await message.answer(f'<b>👀Профиль:</b> @{message.from_user.username}\n'
                         f'<b>🤖Id аккаунта:</b> {message.from_user.id}\n'
                         f'<b>⚡️Количество символов:</b> {chek_status(message.from_user.id)[0]}\n'
                         f'<b>📚Книг было озвучено:</b> {chek_book(message.from_user.id)[0]}', parse_mode='HTML', reply_markup=ikb)



@dp.callback_query_handler(text='back', state='*')
async def cmd_back(callback: types.CallbackQuery):
    await callback.message.delete()
    await callback.message.answer('Вы в главном меню')


@dp.message_handler(text='О нас 💬', state='*')
async def info(message: types.Message):

    await message.answer('Бот создан для твоего саморазвития, простоты доступа к информации.\n\n'
                         'Бот работает на основе ИИ-синтеза. По вопросам: @bovup', reply_markup=ikb)

@dp.message_handler(text='Полный доступ ⚡️', state='*')
async def info(message: types.Message):
    await message.answer(
                         'Как получить больше символов:\n'
                         'Для того что бы получить больше символов, свяжитесь с @bovup, для увеличения символов', reply_markup=ikb_back)


@dp.message_handler(text='Канал 🗣️', state='*')
async def info(message: types.Message):
    await message.answer('Следите за нашими обновлениями', reply_markup=ikb)

@dp.message_handler(text='Статистика')
async def info(message: types.Message):
    res = stat()
    await message.answer(f'Число пользователей: {res[0]}\n'
                         f'Всего озвучено книг: {res[1]}')


class AdminAPI(StatesGroup):
    API = State()

@dp.message_handler(text='Изменить API')
async def info(message: types.Message):
    await message.answer('Отправьте свой API', reply_markup=ikb_stop)
    await AdminAPI.API.set()

@dp.message_handler(state=AdminAPI.API)
async def cal(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['API'] = message.text
    add_api(message.from_user.id, data['API'])
    await message.answer('✅ API успешно обновлен ')
    await state.finish()






class AdminSTATUS(StatesGroup):
    user = State()

@dp.message_handler(text='Выдать символы')
async def info(message: types.Message):
    await message.answer('Отправьте id пользователя и укажите через | количество символов\n\n'
                         'Пример 5968385|2500', reply_markup=ikb_stop)
    await AdminSTATUS.user.set()

@dp.message_handler(state=AdminSTATUS.user)
async def cal(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['user'] = message.text.split('|')
    add_status(simvols=data['user'][1], user_id=data['user'][0])
    await message.answer('✅ Символы отправлены')
    await bot.send_message(data['user'][0], f'Вам начислили: {data["user"][1]} символов!')
    await state.finish()



class AdminDELETE(StatesGroup):
    user = State()

@dp.message_handler(text='Удалить символы')
async def info(message: types.Message):
    await message.answer('Отправьте id пользователя и укажите через | количество символов\n\n'
                         'Пример 5968385|2500', reply_markup=ikb_stop)
    await AdminDELETE.user.set()

@dp.message_handler(state=AdminDELETE.user)
async def cal(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['user'] = message.text.split('|')
    delete_status(simvols=data['user'][1], user_id=data['user'][0])
    await message.answer('✅ Символы удалены')
    await state.finish()


class admin_send(StatesGroup):
    photos = State()
    text = State()


@dp.message_handler(text='Рассылка')
async def send_message(message: types.Message, state: FSMContext):
    if message.from_user.id == ADMIN:
        await message.answer('Отправьте фото рассылки', reply_markup=ikb_stop)
        await admin_send.photos.set()

@dp.message_handler(content_types=['photo'], state=admin_send.photos)
async def cmd_rass(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['photo'] = message.photo[0].file_id
    await message.answer('Отправьте текст', reply_markup=ikb_stop)
    await admin_send.next()

@dp.message_handler(state=admin_send.text)
async def send_message(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['text'] = message.text
    user = all_user()
    try:
        for i in range(len(user)):
            await bot.send_photo(user[i][0], photo=data['photo'], caption=data['text'], parse_mode='HTML')
        await bot.send_message(ADMIN, '✅Рассылка успешно отправлена')
        await state.finish()
    except Exception as e:
        pass



@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    if message.from_user.id == ADMIN:
        db_book()
        await message.answer('Вы в админ панели', reply_markup=kb_admin)

class AdminBib(StatesGroup):
    book = State()
    usrl = State()

@dp.message_handler(text='Добавить книгу')
async def admin(message: types.Message):
    if message.from_user.id == ADMIN:
        await message.answer('Введите название книги', reply_markup=ikb_stop)
        await AdminBib.book.set()

@dp.message_handler(state=AdminBib.book)
async def state_book(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['book'] = message.text
    await message.answer('Введите ссылку на пост', reply_markup=ikb_stop)
    await AdminBib.next()


@dp.message_handler(state=AdminBib.usrl)
async def state_book(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['urls'] = message.text

    if not book_exists(data['book']):
        insert_book(data['book'], data['urls'])
        await message.answer('Данные успешно загружены✅')
        await state.finish()
    else:
        await message.answer('Введите другое название')
        await state.finish()

class User_book(StatesGroup):
    book = State()

@dp.message_handler(text='Библиотека📚')
async def admin(message: types.Message):
    await message.answer('Введите название книги', reply_markup=ikb_stop)
    await User_book.book.set()

@dp.message_handler(state=User_book.book)
async def books_user(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['book'] = message.text

    try:
        books = book_send(data['book'])
        await message.answer('Ссылка на данную книгу:\n'
                             f'{books[0]}')
        await state.finish()
    except IndexError:
        await message.answer('Такой книги не существует')
        await state.finish()


@dp.message_handler(text='Выход')
async def admin(message: types.Message):
    await message.answer('Вы вышли из админ панели', reply_markup=kb_menu)




class Admin_Delete(StatesGroup):
    book = State()


@dp.message_handler(text='Удалить книгу')
async def admin(message: types.Message):
    if message.from_user.id == ADMIN:
        await message.answer('Введите название книги которую хотите удалить', reply_markup=ikb_stop)
        await Admin_Delete.book.set()


@dp.message_handler(state=Admin_Delete.book)
async def state_book(message: types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['book'] = message.text


    if book_exists(data['book']):
        book_delete(data['book'])
        await message.answer('Книга успешно удалена ✅')
        await state.finish()
    else:
        await message.answer('Введите другое название')
        await state.finish()


async def on_startup(_):
    print('Bot started')




if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)