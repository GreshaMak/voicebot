from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from config import *

kb_menu = ReplyKeyboardMarkup(resize_keyboard=True)
kb1 = KeyboardButton('Сканирование 🤖')
kb2 = KeyboardButton('Профиль 👀')
kb3 = KeyboardButton('О нас 💬')
kb4 = KeyboardButton('Канал 🗣️')
kb5 = KeyboardButton('Полный доступ ⚡️')
kb6 = KeyboardButton('Библиотека📚')
kb_menu.add(kb1,kb2).add(kb3,kb4).add(kb5, kb6)

ikb = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton('Канал', url=CHANNALS)],
    [InlineKeyboardButton('Назад', callback_data='back')]
])

ikb_back = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton('Назад', callback_data='back')]
])

kb_admin = ReplyKeyboardMarkup(resize_keyboard=True)
kb1a = KeyboardButton('Изменить API')
kb2a = KeyboardButton('Выдать символы')
kb3a = KeyboardButton('Удалить символы')
kb5a = KeyboardButton('Статистика')
kb6a = KeyboardButton('Рассылка')
kb7a = KeyboardButton('Добавить книгу')
kb8a = KeyboardButton('Удалить книгу')
kb4a = KeyboardButton('Выход')
kb_admin.add(kb1a, kb2a).add(kb3a, kb5a).add(kb7a,kb8a).add(kb6a, kb4a)




ikb_stop = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton('⤵Назад', callback_data='stop_input')]
])

ikb_voice = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton('Дмитрий', callback_data='dmitryi')],
    [InlineKeyboardButton('Назад', callback_data='back')]
])

def show_canals():
    keyword = InlineKeyboardMarkup(row_width=1)
    for chanal in chanals:
        btn = InlineKeyboardButton(text=chanal[0], url=chanal[2])
        keyword.insert(btn)
    btn_Done = InlineKeyboardButton('Я ПОДПИСАЛСЯ', callback_data='done')
    keyword.insert(btn_Done)
    return keyword